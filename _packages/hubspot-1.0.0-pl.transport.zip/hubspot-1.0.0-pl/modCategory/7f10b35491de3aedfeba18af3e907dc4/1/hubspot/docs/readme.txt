----------------------
HubSpot
----------------------
HubSpot for MODX is an Extra that implements HubSpot tracking in it's first version. Simply install the Extra through
the installer and then add the tracking code to the 'HubSpot' module within the 'Extras' MODX menu and you're all set.

Add placeholder `[[++hubspot.tracking_code]]` to your template.

Sterc Online Agency
This extra was built by Sterc Online Agency. More info about Sterc can be found at https://www.sterc.com

Questions or bugs?
Add them to the GitHub issue tracker: https://github.com/Sterc/modx-hubspot/issues